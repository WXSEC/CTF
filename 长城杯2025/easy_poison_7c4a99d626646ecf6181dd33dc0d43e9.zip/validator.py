import torch
import re
from nltk.tokenize import word_tokenize
import os
import pandas as pd

from src.model import TextClassifier
from src.parameters import Parameters
from src.preprocessing import Preprocessing

CLEAN_DATA_PATH = './data/train_set.csv'
SECRET_VALIDATION_PATH = './data/val_set.csv'
FLAG = "flag{fake_flag}"


def preprocess_single_text(text, vocabulary, seq_len):
    text = text.lower()
    text = re.sub(r'[^A-Za-z]+', ' ', text)
    tokens = word_tokenize(text)
    token_ids = [vocabulary[token] for token in tokens if token in vocabulary]
    if len(token_ids) < seq_len:
        token_ids.extend([0] * (seq_len - len(token_ids)))
    else:
        token_ids = token_ids[:seq_len]
    return torch.LongTensor(token_ids).unsqueeze(0)


def validate_model(model_path):
    if not os.path.exists(model_path):
        return False, f"[!] 错误: 未找到模型文件 '{model_path}'。"

    params = Parameters()
    model = TextClassifier(params)
    try:
        model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
        model.eval()
    except Exception as e:
        return False, f"[!] 错误: 模型加载失败。\n{e}"

    try:
        pr = Preprocessing(params.num_words, params.seq_len)
        pr.data = CLEAN_DATA_PATH
        pr.load_data()
        pr.clean_text()
        pr.text_tokenization()
        pr.build_vocabulary()
        vocabulary = pr.vocabulary
    except FileNotFoundError:
        return False, f"[!] 服务器配置错误: 未找到干净数据文件 '{CLEAN_DATA_PATH}' 用于重建词汇表。"

    try:
        validation_df = pd.read_csv(SECRET_VALIDATION_PATH)
    except FileNotFoundError:
        return False, f"[!] 服务器配置错误: 未找到秘密验证集 '{SECRET_VALIDATION_PATH}'。"

    validation_df.drop_duplicates(subset=['text'], inplace=True, keep='first')

    validation_results = []
    all_successful = True

    with torch.no_grad():
        for index, row in validation_df.iterrows():
            text_to_validate = row['text']
            original_label = row['target']
            attack_success_label = 1 - original_label

            input_tensor = preprocess_single_text(text_to_validate, vocabulary, params.seq_len)
            output = model(input_tensor)
            prediction_score = output.item()
            predicted_label = 1 if prediction_score >= 0.5 else 0

            is_success = (predicted_label == attack_success_label)
            if not is_success:
                all_successful = False

            validation_results.append({
                "text": text_to_validate,
                "original": original_label,
                "expected_attack": attack_success_label,
                "predicted": predicted_label,
                "success": "成功" if is_success else "失败"
            })

    #
    result_details_list = []
    for res in validation_results:
        detail_str = (
            f"秘密验证样本: '{res['text']}'\n"
            f"  - 原始标签 (来自val_set.csv): {res['original']}\n"
            f"  - 攻击目标 (应预测为): {res['expected_attack']}\n"
            f"  - 你的模型预测: {res['predicted']}  [--> {res['success']}]"
        )
        result_details_list.append(detail_str)

    separator = "\n" + "-" * 20 + "\n"
    result_message = "验证详情:\n"  + separator.join(result_details_list)
    if all_successful:
        final_message = "🎉🎉🎉 攻击成功! 🎉🎉🎉\n秘密验证样本均被成功误导！\n\n" + result_message + f"\n[*] 您的 Flag 是: {FLAG}"
        return True, final_message
    else:
        final_message = "😞 攻击失败 😞\n秘密验证样本未能按预期进行分类。\n\n" + result_message
        return False, final_message