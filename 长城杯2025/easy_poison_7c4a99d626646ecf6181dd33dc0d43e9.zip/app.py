import os
from flask import Flask, request, render_template, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge

from validator import validate_model

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pth'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 1 * 1024 * 1024


def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.errorhandler(413)
@app.errorhandler(RequestEntityTooLarge)
def handle_file_too_large(e):
    if request.is_json:
        return jsonify(success=False, message='上传失败！文件大小超过了 1MB 的限制。'), 413
    flash('上传失败！文件大小超过了 1MB 的限制。')
    return redirect(url_for('index'))


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'model_file' not in request.files:
        return jsonify(success=False, message='请求中未找到文件部分'), 400

    file = request.files['model_file']

    if file.filename == '':
        return jsonify(success=False, message='未选择任何文件'), 400

    if file and allowed_file(file.filename):
        filename = "submitted_model.pth"
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        is_success, message = validate_model(filepath)

        try:
            if os.path.exists(filepath):
                os.remove(filepath)
                print(f"[*] 临时文件已成功删除: {filepath}")
        except Exception as e:

            print(f"[!] 警告: 删除文件失败 {filepath}。错误: {e}")

        return jsonify(success=is_success, message=message)
    else:
        return jsonify(success=False, message='文件类型不允许！请上传 .pth 文件。'), 400


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)