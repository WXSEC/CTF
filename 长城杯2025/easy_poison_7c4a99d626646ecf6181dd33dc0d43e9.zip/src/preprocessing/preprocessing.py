import re
import nltk
import numpy as np
import pandas as pd
import os
from sklearn.model_selection import train_test_split
from nltk.tokenize import word_tokenize
from nltk.data import load
# nltk.download('punkt_tab')
class Preprocessing:
    def __init__(self, num_words, seq_len):
        self.data = './data/train_set.csv'
        self.num_words = num_words
        self.seq_len = seq_len
        self.vocabulary = None
        self.x_tokenized = None
        self.x_padded = None
        self.x_raw = None
        self.y = None

        self.x_train = None
        self.x_test = None
        self.y_train = None
        self.y_test = None

        try:
            nltk.data.load('tokenizers/punkt_tab/english.pickle')
            print("✅ NLTK punkt_tab 资源加载成功（来自默认路径）")
        except LookupError as e:
            raise RuntimeError(
                f"❌ NLTK punkt_tab 资源未找到！请检查 Docker 镜像是否正确重命名文件夹。\n错误详情：{str(e)}"
            )

    def load_data(self):
        df = pd.read_csv(self.data, encoding='utf-8')
        df.drop(['id', 'keyword', 'location'], axis=1, inplace=True, errors='ignore')
        df.dropna(subset=['text'], inplace=True)
        df['text'] = df['text'].astype(str)
        self.x_raw = df['text'].values
        self.y = df['target'].values

    def clean_text(self):
        self.x_raw = [str(x).lower() for x in self.x_raw]
        self.x_raw = [re.sub(r'[^A-Za-z]+', ' ', x) for x in self.x_raw]

    def text_tokenization(self):
        self.x_raw = [word_tokenize(x) for x in self.x_raw]

    def build_vocabulary(self):
        self.vocabulary = dict()
        fdist = nltk.FreqDist()
        for sentence in self.x_raw:
            for word in sentence:
                fdist[word] += 1
        common_words = fdist.most_common(self.num_words)
        common_words.sort(key=lambda x: x[0])
        for idx, word in enumerate(common_words):
            self.vocabulary[word[0]] = (idx + 1)

    def word_to_idx(self):
        self.x_tokenized = list()
        for sentence in self.x_raw:
            temp_sentence = list()
            for word in sentence:
                if word in self.vocabulary.keys():
                    temp_sentence.append(self.vocabulary[word])
            self.x_tokenized.append(temp_sentence)

    def padding_sentences(self):
        pad_idx = 0
        self.x_padded = list()
        for sentence in self.x_tokenized:
            while len(sentence) < self.seq_len:
                sentence.insert(len(sentence), pad_idx)
            self.x_padded.append(sentence)
        self.x_padded = np.array(self.x_padded)

    def split_data(self):
        self.x_train, self.x_test, self.y_train, self.y_test = train_test_split(
            self.x_padded, self.y, test_size=0.25, random_state=42
        )
