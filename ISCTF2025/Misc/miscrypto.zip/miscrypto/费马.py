#这是一道费马，对

from Crypto.Util.number import *
flag = b'ISCTF{}'
n = p*q
phi = (p-1)*(q-1)
m = bytes_to_long(flag)
c = pow(m, e, n)
e = 65537

#n=
#c=
#?但都不给要我怎么做啊!